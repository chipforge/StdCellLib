* This is a template NMOS model that should be further improved

.model  NMOS_VTL  nmos  level = 54
 
.model  PMOS_VTL  pmos  level = 54

